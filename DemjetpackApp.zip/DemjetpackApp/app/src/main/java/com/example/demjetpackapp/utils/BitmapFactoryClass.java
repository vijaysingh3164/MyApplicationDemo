package com.example.demjetpackapp.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.ByteArrayOutputStream;

public class BitmapFactoryClass {

    public static int REQUIRE_HEIGHT = 480, REQUIRE_WIDTH = 320;
    public static int REQUIRE_HEIGHT_UPLOAD = 1000, REQUIRE_WIDTH_UPLOAD = 800;

    public static String ByteToBase64StringConversion(byte[] myBitmap) {
        String base64Result;
        base64Result = Base64.encodeToString(myBitmap, Base64.DEFAULT);
        return base64Result;
    }

    public static byte[] decodeSampledBitmapFromResourceForUpload(String filePath) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        final int height = options.outHeight;
        final int width = options.outWidth;
        options.inSampleSize = calculateInSampleSize(options, REQUIRE_WIDTH, REQUIRE_HEIGHT);
        options.inJustDecodeBounds = false;
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeFile(filePath, options);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    public static Bitmap decodebitmapFromRes(String filePath, int reqWidth, int reqHeight) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(filePath, options);
    }

    //this function will calculate sample size dynamically
    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 6;
            }
        }
        return inSampleSize;
    }

    public static Bitmap base64StringToBitmap(String imageString) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 2;
        byte[] decodedString = Base64.decode(imageString.getBytes(), Base64.DEFAULT);
        Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length, options);
        return decodedBitmap;
    }

    public static String BitmapToBase64StringConvertion(Bitmap myBitmap) {
        String base64Result;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] data = baos.toByteArray();
        base64Result = Base64.encodeToString(data, 0);
        return base64Result;
    }
}
