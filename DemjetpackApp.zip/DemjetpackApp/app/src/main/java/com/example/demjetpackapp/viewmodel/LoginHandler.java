package com.example.demjetpackapp.viewmodel;

import android.view.View;
import android.widget.Toast;

import com.example.demjetpackapp.model.User;

public class LoginHandler {
    private User user;

    public LoginHandler(User user) {
        this.user = user;
    }

    public void buttonLoginClick(View view) {
        Toast.makeText(view.getContext(), "First name is: " + user.getEmail() + "Last name is " + user.getPassword() + "and password is " + user.getPassword(), Toast.LENGTH_SHORT).show();
    }
}
