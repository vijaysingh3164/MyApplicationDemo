package com.example.demjetpackapp.utils;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class AadhaarValidator {

    private static final int AADHAAR_NUMBER_TOTAL_SYMBOLS = 14; // size of pattern 0000-0000-0000
    private static final int AADHAAR_NUMBER_TOTAL_DIGITS = 12; // max numbers of digits in pattern: 0000 x 3
    private static final int AADHAAR_NUMBER_DIVIDER_MODULO = 5; // means divider position is every 5th symbol beginning with 1
    private static final int AADHAAR_NUMBER_DIVIDER_POSITION = AADHAAR_NUMBER_DIVIDER_MODULO - 1; // means divider position is every 4th symbol beginning with 0
    private static final char AADHAAR_NUMBER_DIVIDER = '-';

    public AadhaarValidator(EditText etAadhaarNumber) {
        etAadhaarNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // noop
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // noop
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!isInputCorrect(s, AADHAAR_NUMBER_TOTAL_SYMBOLS, AADHAAR_NUMBER_DIVIDER_MODULO, AADHAAR_NUMBER_DIVIDER)) {
                    s.replace(0, s.length(), concatString(getDigitArray(s, AADHAAR_NUMBER_TOTAL_DIGITS), AADHAAR_NUMBER_DIVIDER_POSITION, AADHAAR_NUMBER_DIVIDER));
                }
            }
        });
    }

    private boolean isInputCorrect(Editable s, int size, int dividerPosition, char divider) {
        boolean isCorrect = s.length() <= size;
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (i + 1) % dividerPosition == 0) {
                isCorrect &= divider == s.charAt(i);
            } else {
                isCorrect &= Character.isDigit(s.charAt(i));
            }
        }
        return isCorrect;
    }

    private String concatString(char[] digits, int dividerPosition, char divider) {
        final StringBuilder formatted = new StringBuilder();

        for (int i = 0; i < digits.length; i++) {
            if (digits[i] != 0) {
                formatted.append(digits[i]);
                if ((i > 0) && (i < (digits.length - 1)) && (((i + 1) % dividerPosition) == 0)) {
                    formatted.append(divider);
                }
            }
        }

        return formatted.toString();
    }

    private char[] getDigitArray(final Editable s, final int size) {
        char[] digits = new char[size];
        int index = 0;
        for (int i = 0; i < s.length() && index < size; i++) {
            char current = s.charAt(i);
            if (Character.isDigit(current)) {
                digits[index] = current;
                index++;
            }
        }
        return digits;
    }
}
