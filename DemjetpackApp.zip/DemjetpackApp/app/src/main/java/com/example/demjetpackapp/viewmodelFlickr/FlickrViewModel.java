package com.example.demjetpackapp.viewmodelFlickr;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.demjetpackapp.flickrmodel.FlickrResponse;
import com.example.demjetpackapp.networking.NewsRepository;

public class FlickrViewModel extends ViewModel {
    //private NewsRepository newsRepository;
    private MutableLiveData<FlickrResponse> mutableLiveData;
    public void init(String methodName, String API_KEY, String format, int value, String urlS, String searchtxt, int pageno, int noimg){
     if (mutableLiveData!=null){
         return;
     }
     mutableLiveData= NewsRepository.getInstance().getImages( methodName, API_KEY,  format, value, urlS,searchtxt, pageno,noimg);
 }

    public LiveData<FlickrResponse> getUserMutableLiveData() {
        return mutableLiveData;
    }

}
