package com.example.demjetpackapp.networking;

import com.example.demjetpackapp.flickrmodel.FlickrResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    String BASE_URL = "https://api.flickr.com/services/";
    @GET("rest")
    Call<FlickrResponse> getSearchQueryImages(@Query("method") String methodName, @Query("api_key") String API_KEY, @Query("format") String format, @Query("nojsoncallback") int value, @Query("extras") String urlS, @Query("text") String userSearchText, @Query("page") int pageno, @Query("per_page") int noimg);
}
