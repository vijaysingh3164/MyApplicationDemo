package com.example.demjetpackapp.utils;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class BTReceiver extends BroadcastReceiver {

    private Activity mContext;
    public static final int REQUEST_ENABLE_BT = 1;

    /**
     * Constructor with get contenxt of activity
     * @param mContext Used activity context
     */
    public BTReceiver(Activity mContext) {
        this.mContext = mContext;
    }


    /**
     * Deletect bluetooth off action and start again bluetooth immediately.
     * @param context context of current activity
     * @param intent intent of current activity
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
        if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
            final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
            switch (state) {
                case BluetoothAdapter.STATE_OFF:
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    mContext.startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                    break;
                case BluetoothAdapter.STATE_TURNING_OFF:
                    break;
                case BluetoothAdapter.STATE_ON:
                    break;
                case BluetoothAdapter.STATE_TURNING_ON:
                    break;
            }
        }
    }
}
