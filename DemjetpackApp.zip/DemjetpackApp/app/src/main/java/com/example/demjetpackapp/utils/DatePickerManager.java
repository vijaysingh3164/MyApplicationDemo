package com.example.demjetpackapp.utils;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DatePickerManager {
    String date;
    DatePickerDialog datePickerDialog;
    Context context;
    private int mYear, mMonth, mDay;
    private int mHour, mMinute;
    private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            if (mDay<=9){
                //date = mYear + "-" + getMonthName(mMonth + 1) + "-" +0+mDay;
                date ="0"+mDay + "/" + getMonthName(mMonth + 1) + "/" +mYear;
               // date = getMonthName(mMonth + 1)+ "/" + "0"+mDay + "/" +mYear;
            }
            else {
             date = mDay + "/" + getMonthName(mMonth + 1) + "/" + mYear;
             //   date = getMonthName(mMonth + 1)+ "/" +mDay + "/" +mYear;
            //date = mYear + "-" + getMonthName(mMonth + 1) + "-" + mDay;

            }
        }
    };


    private DatePickerDialog.OnDateSetListener mDateSetListener1 = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            if (mDay<=9){
                //date = mYear + "-" + getMonthName(mMonth + 1) + "-" +0+mDay;
                date ="0"+mDay + "-" + getFullMonthName(mMonth + 1) + "-" +mYear;
                // date = getMonthName(mMonth + 1)+ "/" + "0"+mDay + "/" +mYear;
            }
            else {
                date = mDay + "-" + getFullMonthName(mMonth + 1) + "-" + mYear;
                //   date = getMonthName(mMonth + 1)+ "/" +mDay + "/" +mYear;
                //date = mYear + "-" + getMonthName(mMonth + 1) + "-" + mDay;

            }
        }
    };


    public void gettimePickerDialog(final EditText txt) {
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(context,
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {

                        txt.setText(hourOfDay + ":" + minute);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }


    public DatePickerManager(Context context) {
        this.context = context;
    }

    public static String setMonthName(int month) {
        String monthName = "";
        monthName = getFullMonthName(month);
        //Calendar c=Calendar.getInstance();
        //monthName=c.getDisplayName(Calendar.MONTH,Calendar.LONG, Locale.getDefault());
        // long time=c.get(month);
        //SimpleDateFormat sdf=new SimpleDateFormat("MMMM");
        //Date date=new Date(time);
        //monthName=sdf.format(date);
        return monthName;
    }

    public static String getFullMonthName(int month) {
        switch (month) {
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "August";
            case 9:
                return "September";
            case 10:
                return "October";
            case 11:
                return "November";
            case 12:
                return "December";
            default:
                return "Month";
        }
    }

    public int getCurrentMonth() {
        Calendar cc = Calendar.getInstance();
        int currentMonth = cc.get(Calendar.MONTH) + 1;
        return currentMonth;
    }

    public String getCurrentDate() {
        Calendar c = Calendar.getInstance();
        int month = c.get(Calendar.MONTH) + 1;
        String monthname = getMonthName(month);
        String sDate = c.get(Calendar.DAY_OF_MONTH) + ", " + monthname;
        return sDate;
    }
    public String getMonthName(int month) {
        switch (month) {
            case 1:
                return "01";
            case 2:
                return "02";
            case 3:
                return "03";
            case 4:
                return "04";
            case 5:
                return "05";
            case 6:
                return "06";
            case 7:
                return "07";
            case 8:
                return "08";
            case 9:
                return "09";
            case 10:
                return "10";
            case 11:
                return "11";
            case 12:
                return "12";
        }
        return null;

    }
   /* public String getMonthName(int month) {
        switch (month) {
            case 1:
                return "Jan";
            case 2:
                return "Feb";
            case 3:
                return "Mar";
            case 4:
                return "Apr";
            case 5:
                return "May";
            case 6:
                return "Jun";
            case 7:
                return "Jul";
            case 8:
                return "Aug";
            case 9:
                return "Sep";
            case 10:
                return "Oct";
            case 11:
                return "Nov";
            case 12:
                return "Dec";
        }
        return null;

    }*/

    public void getDat(final EditText fromDate, final EditText et2) {
        datePickerDialog = new DatePickerDialog(context, mDateSetListener, mYear, mMonth, mDay);

        if (!fromDate.getText().toString().trim().equals("")) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        date = et2.getText().toString();
                        et2.setText(date);
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        et2.setText(dateTo(et2));
                    }
                }
            });

            datePickerDialog.setCancelable(false);
            datePickerDialog.getDatePicker().setMinDate(disableDates(fromDate));
            datePickerDialog.show();
        } else {
            Toast.makeText(context, "Please select From Date First.", Toast.LENGTH_SHORT).show();
            // ApplicationClass.showToast("Please select From Date First.");
        }

    }

    public long disableDates(EditText et2) {
        long selectedDate = 0;
        try {
            String date = et2.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date dated = sdf.parse(date);
            selectedDate = dated.getTime();
            //datePickerDialog.getDatePicker().setMinDate(selectedDate);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return selectedDate;
    }

    public boolean compareDates(EditText et1, EditText et2) {
        boolean check = false;
        try {
            String dateFrom = et1.getText().toString();
            String dateTo = et2.getText().toString();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
            Date fromDate = simpleDateFormat.parse(dateFrom);
            Date toDate = simpleDateFormat.parse(dateTo);
            long firstDate = fromDate.getTime();
            long secondDate = toDate.getTime();
            check = secondDate >= firstDate;
        } catch (Exception exc) {
            exc.printStackTrace();
        }
        return check;
    }

    private String dateTo(EditText et2) {
        DatePicker datePicker = datePickerDialog.getDatePicker();
        datePicker.setMinDate(disableDates(et2));
        mDateSetListener.onDateSet(datePicker, datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        return date;
    }

    private String chdate() {
        DatePicker datePicker = datePickerDialog.getDatePicker();
        mDateSetListener1.onDateSet(datePicker, datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        return date;
    }

    private String date() {
        DatePicker datePicker = datePickerDialog.getDatePicker();
        mDateSetListener.onDateSet(datePicker, datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        return date;
    }

    public String getDate() {
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        date = mDay + "-" + getMonthName(mMonth + 1) + "-" + mYear;
        return date;
    }


    public void getcheckDatePickDialog(final EditText editText) {
        Calendar currentDate = Calendar.getInstance();
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        int month = currentDate.get(Calendar.MONTH);
        int year = currentDate.get(Calendar.YEAR);
        datePickerDialog = new DatePickerDialog(context,android.R.style.Theme_Holo_Dialog, mDateSetListener1, year, month, day);
        datePickerDialog.getDatePicker().setSpinnersShown(true);
        // datePickerDialog.getDatePicker().setCalendarViewShown(false);
        if (editText != null) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        //date = editText.getText().toString();
                        editText.setText("");
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        editText.setText(chdate());

                    }
                }
            });
            datePickerDialog.setCancelable(false);
            datePickerDialog.show();
        }

    }


    public void getCurrentDatePickDialog(final EditText editText) {
        Calendar currentDate = Calendar.getInstance();
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        int month = currentDate.get(Calendar.MONTH);
        int year = currentDate.get(Calendar.YEAR);
        datePickerDialog = new DatePickerDialog(context,android.R.style.Theme_Holo_Dialog, mDateSetListener, year, month, day);
        datePickerDialog.getDatePicker().setSpinnersShown(true);
       // datePickerDialog.getDatePicker().setCalendarViewShown(false);
        if (editText != null) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        //date = editText.getText().toString();
                        editText.setText("");
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        editText.setText(date());

                    }
                }
            });
            datePickerDialog.setCancelable(false);
            datePickerDialog.show();
        }

    }

    public void getCurrentDateTimePickDialog(final EditText editText) {
        Calendar currentDate = Calendar.getInstance();
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        int month = currentDate.get(Calendar.MONTH);
        int year = currentDate.get(Calendar.YEAR);
        datePickerDialog = new DatePickerDialog(context,android.R.style.Theme_Holo_Dialog, mDateSetListener, year, month, day);
        datePickerDialog.getDatePicker().setSpinnersShown(true);
        // datePickerDialog.getDatePicker().setCalendarViewShown(false);
        if (editText != null) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        //date = editText.getText().toString();
                        editText.setText("");
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        //editText.setText(date());
                        gettimePickerDialog(editText,date());
                    }
                }
            });
            datePickerDialog.setCancelable(false);
            datePickerDialog.show();
        }

    }

    public void getIssueDatePickDialog(final EditText editText) {
        Calendar currentDate = Calendar.getInstance();
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        int month = currentDate.get(Calendar.MONTH);
        int year = currentDate.get(Calendar.YEAR);
        datePickerDialog = new DatePickerDialog(context,android.R.style.Theme_Holo_Dialog, mDateSetListener, year, month, day);
        datePickerDialog.getDatePicker().setSpinnersShown(true);
        // datePickerDialog.getDatePicker().setCalendarViewShown(false);
        if (editText != null) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        //date = editText.getText().toString();
                        editText.setText("");
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        editText.setText(date());

                    }
                }
            });
            datePickerDialog.setCancelable(false);
            datePickerDialog.show();
            datePickerDialog.getDatePicker().setMaxDate(currentTime());
        }

    }

    public void getExpiryDateDialog(final EditText editText) {
        Calendar currentDate = Calendar.getInstance();
        int day = currentDate.get(Calendar.DAY_OF_MONTH);
        int month = currentDate.get(Calendar.MONTH);
        int year = currentDate.get(Calendar.YEAR);
        datePickerDialog = new DatePickerDialog(context,android.R.style.Theme_Holo_Dialog, mDateSetListener, year, month, day);
        datePickerDialog.getDatePicker().setSpinnersShown(true);
        // datePickerDialog.getDatePicker().setCalendarViewShown(false);
        if (editText != null) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        //date = editText.getText().toString();
                        editText.setText("");
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        editText.setText(date());

                    }
                }
            });
            datePickerDialog.setCancelable(false);
            datePickerDialog.show();
            datePickerDialog.getDatePicker().setMinDate(Calendar.getInstance().getTimeInMillis()- 10000);
        }

    }


    public void getExpiryBwDateDialog(final EditText fromDate, final EditText et2) {
        datePickerDialog = new DatePickerDialog(context,android.R.style.Theme_Holo_Dialog, mDateSetListener, mYear, mMonth, mDay);

        if (!fromDate.getText().toString().trim().equals("")) {
            datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_NEGATIVE) {
                        /*date = et2.getText().toString();
                        et2.setText(date);
                        dialog.cancel();*/
                        et2.setText("");
                        dialog.cancel();
                    }
                }
            });
            datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        et2.setText(dateTo(et2));
                    }
                }
            });

            datePickerDialog.setCancelable(false);
            datePickerDialog.getDatePicker().setMinDate(disableDates(fromDate));
            datePickerDialog.show();
        } else {
            Toast.makeText(context, "Please select From Date First.", Toast.LENGTH_SHORT).show();
            // ApplicationClass.showToast("Please select From Date First.");
        }

    }


    public void gettimePickerDialog(final EditText txt, final String date) {
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(context,
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {

                        txt.setText(date+" "+hourOfDay + ":" + minute);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }



    public int calculateAgeWithJava7(Date birthDate, Date currentDate) {
        // validate inputs ...
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        int d1 = Integer.parseInt(formatter.format(birthDate));
        int d2 = Integer.parseInt(formatter.format(currentDate));
        int age = (d2 - d1) / 10000;
        return age;
    }
    public static String currentdate() {
        String currentdat = "";
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        currentdat = dateFormat.format(date);
      //  Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        //currentdat= String.valueOf(timestamp.getTime());
        return currentdat;
    }

    public static long currentTime() {
        long currentdat ;
        Date date = new Date();
        currentdat= date.getTime();
        return currentdat;
    }
    public static String getCurrentdateTime() {
        String currentdate = "";
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm aaa");
        Date date = new Date();
        currentdate = formatter.format(date);
        return currentdate;
    }
}
