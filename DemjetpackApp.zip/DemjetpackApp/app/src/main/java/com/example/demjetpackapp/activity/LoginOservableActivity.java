package com.example.demjetpackapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;

import android.opengl.Visibility;
import android.os.Bundle;
import android.widget.Toast;

import com.example.demjetpackapp.R;
import com.example.demjetpackapp.databinding.ActivityLoginOservableBinding;
import com.example.demjetpackapp.model.User;
import com.example.demjetpackapp.viewmodel.LoginViewModel;

public class LoginOservableActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_login_oservable);
        ActivityLoginOservableBinding binding= DataBindingUtil.setContentView(this,R.layout.activity_login_oservable);

        LoginViewModel loginViewModel=new LoginViewModel();
        binding.setLoginViewModel(loginViewModel);
       /* loginViewModel.getUser().observe(this, new Observer<User>() {
            @Override
            public void onChanged(User user) {
                if (user.getEmail().length() > 0 || user.getPassword().length() > 0)
                    Toast.makeText(getApplicationContext(), "email : " + user.getEmail() + " password " + user.getPassword(), Toast.LENGTH_SHORT).show();
            }
        });*/

        loginViewModel.getUser().observe(LoginOservableActivity.this, user);
    }


    Observer<User> user=new Observer<User>() {
        @Override
        public void onChanged(User user) {

        }
    };
}