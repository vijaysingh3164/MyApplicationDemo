package com.example.demjetpackapp.networking;


import androidx.lifecycle.MutableLiveData;

import com.example.demjetpackapp.flickrmodel.FlickrResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewsRepository {

    private static NewsRepository newsRepository;

    public static NewsRepository getInstance(){
        if (newsRepository == null){
            newsRepository = new NewsRepository();
        }
        return newsRepository;
    }

    private ApiService apiService;

    public NewsRepository(){
        apiService = RetrofitService.cteateService(ApiService.class);
    }



    public MutableLiveData<FlickrResponse> getImages(String methodName, String API_KEY, String format, int value, String urlS, String searchtxt, int pageno, int noimg)
    {
       MutableLiveData<FlickrResponse> flickrData = new MutableLiveData<>();
        apiService.getSearchQueryImages(methodName, API_KEY,  format, value, urlS,searchtxt, pageno,noimg)
                   .enqueue(new Callback<FlickrResponse>() {
            @Override
            public void onResponse(Call<FlickrResponse> call,
                                   Response<FlickrResponse> response) {
                if (response.isSuccessful()){
                    flickrData.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<FlickrResponse> call, Throwable t) {
                flickrData.setValue(null);
            }
        });
        return flickrData;
    }


}
