package com.example.demjetpackapp.flickrmodel;

import com.google.gson.annotations.SerializedName;

public class Image {

    @SerializedName("id")
    private String id;
    @SerializedName("url_s")
    private String imageUrl;


    public void setId(String id) {
        this.id = id;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getId() {
        return id;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
