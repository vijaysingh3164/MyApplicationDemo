package com.example.demjetpackapp.flickrmodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FlickrResponse {
    @SerializedName("photos")
    @Expose
    private Images images;
    @SerializedName("stat")
    @Expose
    private String stat;

    public Images getImages() {
        return images;
    }

    public void setImages(Images images) {
        this.images = images;
    }

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }
}
